-- no-op, 147 is mysql-specific.
-- the following dummy query is added because migration engine doesn't support empty schema files.

select true;
