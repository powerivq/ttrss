insert into ttrss_filter_actions (id,name,description) values (10, 'ignore-tag',
	'Ignore tags');
