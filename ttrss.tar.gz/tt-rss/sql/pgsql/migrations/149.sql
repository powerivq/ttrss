alter table ttrss_feeds alter column auth_pass set default '';
