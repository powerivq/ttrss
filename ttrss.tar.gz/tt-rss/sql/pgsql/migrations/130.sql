BEGIN;

UPDATE ttrss_version SET schema_version = 130;

COMMIT;
