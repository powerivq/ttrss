
insert into ttrss_filter_types (id,name,description) values (5, 'date', 
	'Article Date');

update ttrss_version set schema_version = 46;
