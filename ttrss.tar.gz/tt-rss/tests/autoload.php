<?php
	set_include_path(dirname(__DIR__) ."/include" . PATH_SEPARATOR .
	get_include_path());

	require_once "autoload.php";
	require_once "functions.php";
