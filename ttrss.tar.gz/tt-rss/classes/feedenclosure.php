<?php
class FeedEnclosure {
	public $link;
	public $type;
	public $length;
	public $title;
	public $height;
	public $width;
}

