<?php 
   header("Location: /tt-rss/");
   return;
