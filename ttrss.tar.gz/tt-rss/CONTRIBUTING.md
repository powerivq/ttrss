## Contributing code the right way 

TLDR: it works pretty much like Github.

1. Make an account on Gogs
2. Fork the repository you're interested in
3. Do the needful
4. File a pull request with your changes against master branch.

