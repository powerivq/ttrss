require(['dojo/_base/kernel', 'dojo/ready'], function (dojo, ready) {
        ready(function () {
          Headlines.default_force_to_top = true;
        });
});

